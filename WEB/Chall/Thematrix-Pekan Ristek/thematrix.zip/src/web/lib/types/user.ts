export type User = {
    username: string;
    description: string;
    private: boolean;
};
