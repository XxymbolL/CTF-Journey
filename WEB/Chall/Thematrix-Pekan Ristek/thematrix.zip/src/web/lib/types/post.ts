export type Post = {
    author: string;
    content: string;
    created_at: Date;
    likes: number;
};
