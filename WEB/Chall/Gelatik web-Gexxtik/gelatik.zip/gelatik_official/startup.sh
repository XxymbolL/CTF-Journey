#!/usr/bin/env sh

./myapp migrate
./myapp run